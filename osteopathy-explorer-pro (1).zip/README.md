
# Osteopathy Explorer Pro - Setup Guide

## 1. Google Spreadsheet Setup
Create a Google Sheet with headers: `ID`, `ParentID`, `Label`, `URL`, `Description`, `ImageURL`.

## 2. Google Apps Script
1. Go to **Extensions** > **Apps Script**.
2. Paste `scripts/google_apps_script.js`.
3. Set your `SPREADSHEET_ID` in **Project Settings** > **Script Properties**.
4. **Deploy** as a **Web App** (Set access to "Anyone").

## 3. How to put on a Google Site (VERY EASY)
1. Run the sync script:
   ```bash
   python scripts/sync_data.py --url YOUR_WEB_APP_URL
   ```
2. This generates a file called `google_sites_ready.html`.
3. Open `google_sites_ready.html` in Notepad or VS Code.
4. **Copy all the text** inside that file.
5. In **Google Sites**: Click **Insert** > **Embed** > **Embed Code**.
6. **Paste** the text and click **Insert**.

## 4. Local Development
For local testing with Vite:
```bash
npm install
npm run dev
```
