
import { RawNode } from './types';

// Using RawNode instead of RawMindMapNode as it is the exported interface in types.ts
export const INITIAL_DATA: RawNode[] = [
  { id: "1", parentId: null, label: "Enterprise Strategy", url: "https://example.com/strategy" },
  { id: "2", parentId: "1", label: "Product Roadmap" },
  { id: "3", parentId: "1", label: "Market Analysis", url: "https://example.com/market" },
  { id: "4", parentId: "1", label: "Infrastructure" },
  { id: "5", parentId: "2", label: "Q1 Launch" },
  { id: "6", parentId: "2", label: "Q2 Expansion" },
  { id: "7", parentId: "3", label: "Competitor Research" },
  { id: "8", parentId: "3", label: "Customer Surveys" },
  { id: "9", parentId: "4", label: "Cloud Migration", url: "https://example.com/cloud" },
  { id: "10", parentId: "4", label: "Security Audit" },
  { id: "11", parentId: "5", label: "Beta Testing" },
  { id: "12", parentId: "5", label: "Marketing Sync" },
];

export const LAYOUT_CONFIG = {
  width: 1200,
  height: 800,
  margin: { top: 20, right: 120, bottom: 20, left: 120 },
  nodeWidth: 160,
  nodeHeight: 40,
  rankSeparation: 250, // Increased rank separation as requested
};
